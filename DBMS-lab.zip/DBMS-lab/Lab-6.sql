--Lab 6 Perform SQL Queries for Data Copy (SELECT INTO) 
--From the table DEPOSIT perform the following queries:
--Part – A:
select * from bank_deposit;


--1. Copy all records from DEPOSIT where AMOUNT > 3000 into HIGH_AMOUNT. 
select amount into high_amount from bank_deposit
where amount > 3000;
select * from high_amount;


--2. Copy only CNAME and AMOUNT from DEPOSIT where BNAME = 'MAVDI' into MAVDI_CUSTOMERS.
select cname,amount into MAVDI_CUSTOMERS from bank_deposit
where bname = 'mavdi';
select * from MAVDI_CUSTOMERS;


--3. Copy records of DEPOSIT where ADATE > '2025-01-01' into RECENT_DEPOSITS.  
select adate into RECENT_DEPOSITS from bank_deposit
where ADATE > '2025-01-01';
select * from RECENT_DEPOSITS;

--4. Copy distinct BNAME from DEPOSIT into BRANCH_LIST.  
select distinct bname into BRANCH_LIST from bank_deposit;
select * from BRANCH_LIST;

--5. Copy top 5 records from DEPOSIT into TOP_DEPOSITS.  
select top 5 * into TOP_DEPOSITS from bank_deposit;
select * from TOP_DEPOSITS;

--6. Copy records where AMOUNT between 2000 and 6000 into MID_RANGE.  
select * into MID_RANGE from bank_deposit
where amount between 2000 and 6000
select * from MID_RANGE;

--7. Copy distinct branch names from DEPOSIT into UNIQUE_BRANCH.
select distinct bname into UNIQUE_BRANCH from bank_deposit
select * from UNIQUE_BRANCH;

--8. Copy records with NULL branch into NO_BRANCH_ASSIGNED.  
select * into NO_BRANCH_ASSIGNED from bank_deposit
where bname is null
select * from NO_BRANCH_ASSIGNED;

--9. Copy all records and rename AMOUNT as BALANCE into DEPOSIT_COPY. 
select actno,cname,bname,amount as balance,adate into DEPOSIT_COPY from bank_deposit
select * from DEPOSIT_COPY;

--10. Copy records where BNAME in ('MAVDI','BEDI') into SELECTED_BRANCH. 
select * into SELECTED_BRANCH from bank_deposit
where BNAME in ('MAVDI','BEDI');
select * from SELECTED_BRANCH;

--From the table Student perform the following queries:  
--Part – B:

--11. Create a new table STUDENT_BACKUP from STUDENT without copying any data.
select * into STUDENT_BACKUP from student;
select * from STUDENT_BACKUP;

--12. Copy SNAME and CITY where BRANCH = 'COMPUTER' into CS_STUDENTS.  
select sname,city into CS_STUDENTS from STUDENT_BACKUP
where BRANCH = 'COMPUTER';
select * from CS_STUDENTS;

--13. Copy top 3 students based on SPI into TOPPER_LIST. 
select top 3 * into TOPPER_LIST from STUDENT_BACKUP
order by spi desc;
select * from TOPPER_LIST;

--14. Copy distinct CITY from STUDENT into CITY_LIST
select distinct city into CITY_LIST from STUDENT_BACKUP
select * from CITY_LIST;

--15. Copy records where STDID between 103 and 108 into MID_STUDENTS. 
select * into MID_STUDENTS from STUDENT_BACKUP
where STDID between 103 and 108
select * from MID_STUDENTS;
