--LAB-5

--PART-A
select * from deposit;
--1. Add column state varchar(20). 
ALTER table deposit
add state varchar(20);

--2. Add two more columns city varchar(20) and pincode int. 
alter table deposit
add city varchar(20),
	pincode int;

--3. Change the size of cname column from varchar(50) to varchar(35). 
alter table deposit
alter column cname varchar(35);

--4. Change the data type of amount from decimal to int
alter table deposit
alter column amount int;

--5. Delete column city from the DEPOSIT table. 
alter table deposit
drop column city;

--6. Rename column actno to ano.
SP_RENAME 'deposit.actno','ano';

--7. Rename column bname to branch_name.
SP_RENAME 'deposit.bname','branch_name';

--8. Rename table DEPOSIT to DEPOSIT_DETAIL.  
SP_RENAME 'deposit','deposit_detail';

select * from deposit_detail;

--9. Add column ifsc_code varchar(15). 
alter table deposit_detail
add ifsc_code varchar(15);

--10. Change the size of bname column from varchar(50) to varchar(30).
alter table deposit_detail
alter column branch_name varchar(30);

--part-b

--11. Rename column adate to aopendate.  
SP_RENAME 'deposit_detail.adate','aopendate';

--12. Delete column aopendate from DEPOSIT_DETAIL table. 
alter table deposit_detail
drop column aopendate;

--13. Rename column cname to customer_name. 
SP_RENAME 'deposit_detail.cname','customer_name';

--14. Add column country varchar(20).  
alter table deposit_detail
add country varchar(20);

--15. Add column account_type varchar(15). 

alter table deposit_detail
add account_type varchar(15);

--part-c

--16. Change data type of pincode from int to bigint. 

alter table deposit_detail
alter column pincode bigint;

--17. Delete column account_type. 

alter table deposit_detail
drop column account_type;

--18. Rename column amount to balance. 

SP_RENAME 'deposit_detail.amount','balance';

--19. Add column status varchar(10). 

alter table deposit_detail
add status varchar(10);

--20. Change table name deposit_detail to bank_deposit.

SP_RENAME 'deposit_detail','bank_deposit';
select * from bank_deposit;


--From the table DEPOSIT perform the following queries:  
--Part – A: 

--1. Delete all the records having amount less than or equal to 3000.  
delete from bank_deposit
where amount <= 3000;

--2. Delete all the accounts of ‘BEDI’ branch customer. 
delete from bank_deposit
where bname = 'bedi';

--3. Delete all the accounts having account number greater than 102 and less than 109. 
delete from bank_deposit
where actno > 102 and actno < 109;
