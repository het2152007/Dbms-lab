--From the table STUDENT perform the following queries:  
--Part – A:  

--1. INSERT Procedures: Create stored procedures to insert records into STUDENT tables 
--(SP_INSERT_STUDENT) 

CREATE PROCEDURE SP_INSERT_STUDENT
@STDID INT,
@SNAME VARCHAR(25),
@CITY VARCHAR(25),
@SPI DECIMAL(4,2),
@BRANCH VARCHAR(25)
AS
BEGIN
INSERT INTO STUDENT
VALUES(@STDID,@SNAME,@CITY,@SPI,@BRANCH)
END

EXEC SP_INSERT_STUDENT 116 ,"NIKUNJ" ,"SURAT"  ,8.80 ,"CHEMICAL"

SELECT * FROM STUDENT

--2. INSERT Procedures: Create stored procedures to insert records into DEPOSIT tables  
--(SP_INSERT_DEPOSIT) 

CREATE PROCEDURE SP_INSERT_DEPOSIT
@ACTNO INT,
@CNAME VARCHAR(25),
@BNAME VARCHAR(25),
@AMOUNT INT,
@ADATE DATETIME
AS
BEGIN
INSERT INTO DEPOSIT
VALUES(@ACTNO,@CNAME,@BNAME,@AMOUNT,@ADATE)
END

EXEC SP_INSERT_DEPOSIT 118, "HEMENT" ,"BEDI" ,16000 ,'05-05-2025'

SELECT * FROM DEPOSIT


--3. UPDATE Procedures: Create stored procedure SP_UPDATE_STUDENT to update Branch in STUDENT 
--table. (Update using studentID)

CREATE PROCEDURE SP_UPDATE_STUDENT
@BRANCH VARCHAR(25),
@STDID INT
AS
BEGIN
UPDATE STUDENT
SET BRANCH = @BRANCH
WHERE STDID = @STDID
END

EXEC SP_UPDATE_STUDENT "MECHANICAL",116
EXEC SP_UPDATE_STUDENT "ELECTRICAL",115

SELECT * FROM STUDENT


--4. DELETE Procedures: Create stored procedure SP_DELETE_STUDENT to delete records from STUDENT 
--where Student Name is RAVI. 

CREATE PROCEDURE SP_DELETE_STUDENT
@SNAME VARCHAR(25)
AS
BEGIN
DELETE FROM STUDENT
WHERE SNAME=@SNAME
END

EXEC SP_DELETE_STUDENT "RAVI"

SELECT * FROM STUDENT

--5. SELECT BY PRIMARY KEY: Create stored procedures to select records by primary key 
--(SP_SELECT_STUDENT_BY_ID) from Student table. (Display All Columns) 

CREATE PROCEDURE SP_SELECT_STUDENT_BY_ID
@STDID INT
AS
BEGIN
SELECT * FROM STUDENT
WHERE STDID = @STDID
END

EXEC SP_SELECT_STUDENT_BY_ID 102


--6. Create a stored procedure that shows details of the first 5 students ordered by SPI (Highest First). 

CREATE PROCEDURE SP_SELECT_TOP5_STUDENT_BY_SPI
AS
BEGIN
SELECT TOP 5 * FROM STUDENT
ORDER BY SPI DESC
END

EXEC SP_SELECT_TOP5_STUDENT_BY_SPI

--From the table EMPLOYEE perform the following queries:  
--Part – B:   
--7. Create a stored procedure which displays all employee details. 

CREATE PROCEDURE SP_SELECT_ALL_EMPLOYEE
AS
BEGIN
SELECT * FROM EMPLOYEE
END

EXEC SP_SELECT_ALL_EMPLOYEE


--8. Create a stored procedure that takes department name as input and returns all the employee in that 
--department. 

CREATE PROCEDURE SP_SELECT_ALL_EMPLOYEE_BY_DEPT
@DEPT VARCHAR(25)
AS
BEGIN
SELECT * FROM EMPLOYEE
WHERE DEPARTMENT = @DEPT
END

EXEC SP_SELECT_ALL_EMPLOYEE_BY_DEPT "IT"


--Part – C:  
--9. Create a stored procedure which displays department-wise maximum, minimum, and average salary of 
--employee. 

CREATE PROCEDURE SP_Dept_Salary_Details
AS
BEGIN
    SELECT
        department,
        MAX(salary) AS Maximum_Salary,
        MIN(salary) AS Minimum_Salary,
        AVG(salary) AS Average_Salary
    FROM employee
    GROUP BY department;
END

EXEC SP_Dept_Salary_Details


--10. Create a stored procedure that accepts department name as parameter and returns total salary of their 
--department. 

CREATE PROCEDURE Total_Dept_Salary
@dept_name VARCHAR(50)
AS
BEGIN
    SELECT
        SUM(salary) AS Total_Salary
    FROM employee
    WHERE department = @dept_name;
END 

EXEC Total_Dept_Salary "IT"




SELECT * FROM AUTHOR
SELECT * FROM BOOK
SELECT * FROM PUBLISHER