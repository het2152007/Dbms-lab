--Lab 11 Implement SQL In-Built Functions for Date and Time Handling . Date Functions 

--Part – A: 

--1. Write a query to display the current date & time. Label the column Today_Date. 
select GETDATE() as Today_Date

--2. Write a query to find new date after 365 day with reference to today. 
select dateadd(day,365,getdate())

--3. Display the current date in a format that appears as may 5 1994 12:00AM.
select format(GETDATE(),'MMM dd yyyy hhmmtt')

--4. Display the current date in a format that appears as 03 Jan 1995. 
select format(GETDATE(),'dd MMM yyyy')

--5. Display the current date in a format that appears as Jan 04, 96. 
select format(GETDATE(),'MMM dd,yy')

--6. Write a query to find out total number of months between 31-Dec-08 and 31-Mar-09. 
select DATEDIFF(month, '31-Dec-08' , '31-Mar-09')

--7. Write a query to find out total number of hours between 25-Jan-12 7:00 and 26-Jan-12 10:30. 
select DATEDIFF(HOUR, '25-Jan-12 7:00' , '26-Jan-12 10:30')

--8. Write a query to extract Day, Month, Year from given date 12-May-16. 
select datepart(day,'12-May-16'),datepart(MONTH,'12-May-16'),datepart(YEAR,'12-May-16')

--9. Write a query that adds 5 years to current date. 
select DATEADD(year,5,getdate())

--10. Write a query to subtract 2 months from current date. 
select DATEADD(MONTH,-2,getdate())

--11. Extract month from current date using datename () and datepart () function.
select datename(MONTH,getdate()),datepart(MONTH,getdate())

--12. Write a query to find out last date of current month. 
select EOMONTH(GETDATE())

--13. Calculate your age in years and months.
select datediff(YEAR,'2007 MAY 21',getdate()),datediff(MONTH,'2007 MAY 21',getdate())

--Part – B: Perform following queries on DEPOSIT table.  
SELECT * FROM bank_deposit;
--14. Display all records where account date is in the year 2025. 
SELECT * FROM bank_deposit
WHERE datepart(year,adate) = 2025

--15. Display all records where account date is in the month of March. 
SELECT * FROM bank_deposit
WHERE datepart(month,adate) = 04

--16. Display records where account date is after ‘01-Jan-2025’. 
SELECT * FROM bank_deposit
WHERE format(adate,'dd-MMM-yyyy') > '01-Jan-2025'

--17. Display records where account date is before ‘01-Jan-2025’. 
SELECT * FROM bank_deposit
WHERE format(adate,'dd-MMM-yyyy') < '01-Jan-2025'

--18. Display records where day of account date is 1. 
SELECT * FROM bank_deposit
WHERE datepart(day,adate) = 1

--19. Display records where month of account date is greater than 6. 
SELECT * FROM bank_deposit
WHERE datepart(month,adate) > 2

--20. Display records where year of account date is 2026. 
SELECT * FROM bank_deposit
WHERE datepart(year,adate) = 2026
