--Lab 9 
--Perform SQL Queries Using GROUP BY with HAVING Clause and ORDER BY 
--From the tables EMPLOYE perform the following queries 

--Part – A: 

--1. Display cities where total salary of employees greater than 20000.
select city,sum(salary) as total_salary from emp
group by city
having sum(salary)>20000

--2. Display departments having average salary greater than 12000.
select dept,avg(salary) as avg from emp
group by dept
having avg(salary)>12000

--3. Display departments having total salary greater than 20000. 
select dept,sum(salary) as toral_salary from emp
group by dept
having sum(salary)>20000

--4. Display departments having number of employees greater than 2.
select dept,count(eid) as totalemp from emp
group by dept
having count(eid)>2

--5. Display cities where minimum salary less than 7000.
select city,min(salary) as min_salary from emp
group by city
having min(salary)<7000

--6. Display cities where average salary less than 12000.
select city,avg(salary) as avg_salary from emp
group by city
having avg(salary)<12000

--7. Display departments where maximum salary greater than 14000.
select dept,max(salary) as total_salary from emp
group by dept
having max(salary)>14000

--8. Display cities where total salary greater than equal to 30000. 
select city,sum(salary) as total_salary from emp
group by city
having sum(salary)>=30000

--9. Display departments having number of employees equal to 2. 
select dept from emp
group by dept
having count(eid)=2

--10. Display cities having number of female employees greater than equal to 1. 
select city from emp
where gender='female'
group by city
having count(eid)=1

--11. Display departments where minimum salary of male employees greater than 7000.
select dept from emp
where gender='male'
group by dept
having min(salary)>7000

--12. Display cities where maximum salary of female employees less than 13000.
select city from emp
where gender = 'female'
group by city
having max(salary) <13000

--13. Display departments where average salary greater than 10000 and less than 14000. 
select dept from emp
group by dept
having avg(salary) > 10000 and avg(salary) <14000

--14. Display cities where number of employees joined before 2023 greater than 1. 
select * from emp
select city from emp
where joiningyear < 2023
group by city
having count(*) > 1

--15. Display cities where total salary of male employees greater than 15000, ordered by total salary.
select city from emp
where gender = 'male'
group by city
having sum(salary) > 15000
order by sum(salary)

--16. Display departments where maximum salary greater than 13000, ordered by max salary. 
select dept from emp
group by dept
having max(salary) > 13000
order by max(salary)

--17. Display cities where total salary of male employees greater than 15000. 
select city from emp
where gender = 'male'
group by city
having sum(salary) > 15000

--18. Display departments where employees joined after 2022 and count greater than 1.
select dept from emp
where joiningyear > 2022
group by dept
having count(*) > 1

--19. Display departments where average salary of female employees greater than 8000.  
select dept from emp
where gender = 'female'
group by dept
having avg(salary) > 8000

--20. Display departments having total salary greater than 20000 and less than 40000.  
select dept from emp
group by dept
having sum(salary) > 20000 and sum(salary)<40000

--Part – B: 

--21. Display departments having total salary of employees joined after 2021 greater than 20000.
select dept from emp
where joiningyear > 2021
group by dept
having sum(salary) > 20000

--22. Display cities where average salary of employees joined after 2022 greater than 10000. 
select city from emp
where joiningyear > 2022
group by city
having avg(salary) > 10000

--23. Display cities having number of distinct departments greater than 1.
select city from emp
group by city
having count(distinct dept) > 1

--24. Display cities where maximum salary of employees joined before 2022 greater than 12000.
select city from emp
where joiningyear < 2022
group by city
having max(salary) > 12000

--25. Display departments where total salary of female employees less than 15000.
select dept from emp
where gender = 'female'
group by dept
having sum(salary) < 15000


--Part – C: 

--26. Display cities where number of male employees greater than female employees.  
select city from emp
group by city 
having sum(case when gender='male' then 1 else 0 end ) 
> sum(case when gender='female' then 1 else 0 end )


--27. Display departments having number of cities greater than 1. 
select dept from emp
group by dept 
having count(distinct city) > 1;

--28. Display cities where total salary excluding IT department greater than 15000.  
select city from emp
where dept != 'it'
group by city
having sum(salary) > 15000

--29. Display departments where average salary excluding HR employees greater than 11000.
select dept from emp
where dept != 'hr'
group by dept
having avg(salary) > 11000

--30. Display departments where total salary of male employees greater than female employees.  
select dept from emp
group by dept
having sum(case when gender='male' then salary else 0 end)
> sum(case when gender='female' then salary else 0 end)
