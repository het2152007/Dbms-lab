-- 1. Department-wise salary statistics

ALTER PROCEDURE DeptSalaryStats
    @DEPT VARCHAR(50)
AS
BEGIN
    SELECT
        DEPARTMENT,
        SUM(SALARY) AS TOTAL_SALARY,
        AVG(SALARY) AS AVG_SALARY,
        MIN(SALARY) AS MIN_SALARY,
        MAX(SALARY) AS MAX_SALARY
    FROM EMPLOYEE
    WHERE DEPARTMENT = @DEPT
    GROUP BY DEPARTMENT;
END;


EXEC DeptSalaryStats @DEPT = 'IT';



-- 2. Employees who joined in a given year

ALTER PROCEDURE EmployeesByYear
    @YEAR INT
AS
BEGIN
    SELECT *
    FROM EMPLOYEE
    WHERE JOININGYEAR = @YEAR;
END;


EXEC EmployeesByYear @YEAR = 2022;



-- 3. Search employees using partial city name

CREATE PROCEDURE SearchEmployeeByCity
    @CITY VARCHAR(100)
AS
BEGIN
    SELECT *
    FROM EMPLOYEE
    WHERE CITY LIKE '%' + @CITY + '%';
END;


EXEC SearchEmployeeByCity @CITY = 'RAJ';

SELECT * FROM EMPLOYEE

-- 4. Employees earning more than a given salary

CREATE PROCEDURE EmployeesAboveSalary
    @SALARY DECIMAL(10,2)
AS
BEGIN
    SELECT *
    FROM EMPLOYEE
    WHERE SALARY > @SALARY
    ORDER BY SALARY DESC;
END;


EXEC EmployeesAboveSalary @SALARY = 10000;

SELECT * FROM EMPLOYEE

-- 5. Top N highest-paid employees from each department

CREATE PROCEDURE TopNByDepartment
    @N INT
AS
BEGIN
    SELECT *
    FROM
    (
        SELECT *,
            DENSE_RANK() OVER (
                PARTITION BY DEPARTMENT
                ORDER BY SALARY DESC
            ) AS SALARY_RANK
        FROM EMPLOYEE
    ) AS T
    WHERE SALARY_RANK <= @N
    ORDER BY DEPARTMENT, SALARY DESC;
END;


EXEC TopNByDepartment @N = 3;



-- 6. Increase salary department-wise by percentage

CREATE PROCEDURE IncreaseDeptSalary
    @DEPT VARCHAR(50),
    @PERCENT DECIMAL(5,2)
AS
BEGIN
    UPDATE EMPLOYEE
    SET SALARY = SALARY + (SALARY * @PERCENT / 100)
    WHERE DEPARTMENT = @DEPT;

    SELECT @@ROWCOUNT AS EMPLOYEES_UPDATED;
END;


EXEC IncreaseDeptSalary
    @DEPT = 'Computer',
   @PERCENT = 10;



-- 7. Employees with experience greater than
-- or equal to the given years

CREATE PROCEDURE EmployeesByExperience
    @YEARS INT
AS
BEGIN
    SELECT *
    FROM EMPLOYEE
    WHERE JOININGYEAR <= DATEADD(YEAR, -@YEARS, GETDATE())
    ORDER BY JOININGYEAR;
END;


EXEC EmployeesByExperience @YEARS = 5;



-- 8. Display last N employees who joined

CREATE PROCEDURE LastNEmployees
    @N INT
AS
BEGIN
    SELECT TOP (@N) *
    FROM EMPLOYEE
    ORDER BY JOININGYEAR DESC, E_ID DESC;
END;


EXEC LastNEmployees @N = 5;

SELECT * FROM EMPLOYEE


-- PART B

-- 9. Display all books written by a given author

CREATE PROCEDURE BooksByAuthor
    @AUTHOR_NAME VARCHAR(100)
AS
BEGIN
    SELECT A.AuthorName, B.*
    FROM AUTHOR A
    INNER JOIN BOOK B
        ON A.AuthorID = B.AuthorID
    WHERE A.AuthorName = @AUTHOR_NAME;
END;


EXEC BooksByAuthor @AUTHOR_NAME = 'R.K. Narayan';



-- 10. Display books published after a given year

CREATE PROCEDURE BooksAfterYear
    @YEAR INT
AS
BEGIN
    SELECT *
    FROM BOOK
    WHERE PublicationYear > @YEAR
    ORDER BY PublicationYear;
END;


EXEC BooksAfterYear @YEAR = 2020;



-- 11. Display authors from a given country with their books

CREATE PROCEDURE AuthorsByCountry
    @COUNTRY VARCHAR(100)
AS
BEGIN
    SELECT A.AuthorID, A.AuthorName, A.Country,
           B.BookID, B.TITLE, B.PublicationYear, B.Price
    FROM AUTHOR A
    INNER JOIN BOOK B
        ON A.AuthorID = B.AuthorID
    WHERE A.Country = @COUNTRY;
END;


EXEC AuthorsByCountry @COUNTRY = 'India';



-- 12. Display top N most expensive books
-- with author and publisher details

CREATE PROCEDURE TopExpensiveBooks
    @N INT
AS
BEGIN
    SELECT TOP (@N)
           B.BookID, B.TITLE, B.Price,
           A.AuthorName,
           P.PublisherName
    FROM BOOK B
    INNER JOIN AUTHOR A
        ON B.AuthorID = A.AuthorID
    INNER JOIN PUBLISHER P
        ON B.PublisherID = P.PublisherID
    ORDER BY B.Price DESC;
END;


EXEC TopExpensiveBooks @N = 5;



-- PART C

-- 13. Count books published by a given publisher

CREATE PROCEDURE BooksByPublisher
    @PUBLISHER_NAME VARCHAR(100)
AS
BEGIN
    SELECT P.PublisherName,
           COUNT(B.BookID) AS Total_Books
    FROM PUBLISHER P
    LEFT JOIN BOOK B
        ON P.PublisherID = B.PublisherID
    WHERE P.PublisherName = @PUBLISHER_NAME
    GROUP BY P.PublisherName;
END;


EXEC BooksByPublisher @PUBLISHER_NAME = 'ABC Publications';



-- 14. Display books within a given price range

CREATE PROCEDURE BooksByPriceRange
    @MIN_PRICE DECIMAL(10,2),
    @MAX_PRICE DECIMAL(10,2)
AS
BEGIN
    SELECT *
    FROM BOOK
    WHERE Price BETWEEN @MIN_PRICE AND @MAX_PRICE
    ORDER BY Price;
END;


EXEC BooksByPriceRange
    @MIN_PRICE = 100,
    @MAX_PRICE = 500;



-- 15. Delete all books written by a given author ID

CREATE PROCEDURE DeleteBooksByAuthor
    @AUTHOR_ID INT
AS
BEGIN
    DELETE FROM BOOK
    WHERE AuthorID = @AUTHOR_ID;

    SELECT @@ROWCOUNT AS Deleted_Books;
END;


EXEC DeleteBooksByAuthor @AUTHOR_ID = 101;
