--Lab 7 Perform SQL Pattern Searching Using LIKE Operator 
--From the tables EMPLOYEE perform the following queries: 
--Part – A: 
select * from emp;
--1. Display employees detail whose FIRSTNAME starts with ‘H’. 
select * from emp 
where fname like 'h%'

--2. Display employees detail whose FIRSTNAME consists of exactly 5 characters.
select * from emp 
where fname like '_____'


--3. Display employees detail whose CITY ends with ‘T’ and has 6 characters.
select * from emp 
where city like '_____%t'

--4. Display employees detail whose LASTNAME ends with ‘EL’.
select * from emp 
where lname like '%el'

--5. Display employees detail whose FIRSTNAME starts with ‘R’ and ends with ‘A’. 
select * from emp 
where fname like 'r%a'

--6. Display employees detail whose FIRSTNAME starts with ‘V’ and third character is ‘S’.
select * from emp 
where fname like 'v%_a'

--7. Display employees detail whose CITY is NULL and FIRSTNAME has 6 characters. 
select * from emp 
where fname like '______' and city is null

--8. Display employees detail whose FIRSTNAME contains ‘AR’.
select * from emp 
where fname like '%ar%'

--9. Display employees detail whose CITY starts with ‘R’ or ‘B’.
select * from emp 
where city like '[r,b]%'

--10. Display employees detail whose DEPARTMENT is NOT NULL.
select * from emp 
where dept is not null

--11. Display employees detail whose FIRSTNAME starts from alphabet A to H.
select * from emp 
where fname like '[a,e,i,o,u]%'

--12. Display employees detail whose second character of FIRSTNAME is a vowel. 
select * from emp 
where fname like '_[a,e,i,o,u]%'

--13. Display employees detail whose FIRSTNAME length ≥ 5. 
select * from emp 
where fname like '_____%'

--14. Display employees detail whose LASTNAME starts with ‘PA’. 
select * from emp 
where lname like '[p,a]%'

--15. Display employees detail whose CITY does not start with ‘B’. 
select * from emp 
where city like '[^b]%'

--16. Display employees whose second character of FIRSTNAME is a not vowel. 
select * from emp 
where fname like '_[^a,e,i,o,u]%'

--17. Display employees whose JOINING YEAR last digit is 4 or 6. 
select * from emp 
where joiningyear like '%[4,6]'

--18. Display employees detail whose FIRSTNAME starts with ‘H’, ends with ‘I’, and CITY contains ‘RA’.
select * from emp 
where fname like 'h%i' and city like '%[r,a]%'

--19. Display employees detail whose FIRSTNAME contains ‘A’, CITY ends with ‘D’, and DEPARTMENT is NOT NULL. 
select * from emp 
where fname like '%a%' and city like '%d' and dept is not null;

--20. Display employees whose second and third characters of FIRSTNAME are vowels and CITY starts with ‘R’.
select * from emp 
where fname like '_[a,e,i,o,u][a,e,i,o,u]%' and city like 'r%'
