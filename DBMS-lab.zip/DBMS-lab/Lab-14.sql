--lab 14 Implement Complex SQL Joins with Multiple Tables and Conditions 
-- From the table DEPARTMENT and PERSON perform the following queries:  

--Part – A: 

--1. Combine information from Person and Department table using cross join or Cartesian product. 
SELECT *
FROM PERSON
CROSS JOIN DEPARTMENT;

--2. Find all persons with their department name 
SELECT P.PersonName, D.DepartmentName
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID;

--3. Find all persons with their department name & code. 
SELECT P.PersonName, D.DepartmentName, D.DepartmentCode
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID;

--4. Find all persons with their department code and location. 
SELECT P.PersonName, D.DepartmentCode, D.Location
FROM PERSON P
JOIN DEPARTMENT D
ON P.Departmentid = D.DEPARTMENTID;


--5. Find the detail of the person who belongs to Mechanical department. 
SELECT P.*
FROM PERSON P
JOIN DEPARTMENT D
ON P.Departmentid = D.DEPARTMENTID
WHERE D.DepartmentName = 'Mechanical';


--6. Final person’s name, department code and salary who lives in Ahmedabad city.  
SELECT P.PersonName, d.DepartmentCode, P.Salary
FROM PERSON P
JOIN DEPARTMENT D
ON P.Departmentid = D.DEPARTMENTID
WHERE P.City = 'Ahmedabad';


--7. Find the person's name whose department is in C-Block. 
SELECT P.PersonName
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID
WHERE D.Location = 'C-Block';


--8. Retrieve person name, salary & department name who belongs to Jamnagar city. 
SELECT P.PersonName, P.Salary, D.DepartmentName
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID
WHERE P.City = 'Jamnagar';


--9. Retrieve person’s detail who joined the Civil department after 1-Aug-2001. 
SELECT P.*
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID
WHERE D.DepartmentName = 'Civil'
AND P.JoiningDate > '2001-08-01';

--10. Display all the person's name with the department whose joining date difference with the current date  is more than 25 years. 
SELECT P.PersonName, D.DepartmentName
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID
WHERE DATEDIFF(YEAR, P.JoiningDate, GETDATE()) > 25;

--11. Find department wise person counts. 
SELECT D.DepartmentName, COUNT(P.PersonName) AS PersonCount
FROM DEPARTMENT D
LEFT JOIN PERSON P
ON D.DEPARTMENTID = P.DEPARTMENTID
GROUP BY D.DepartmentName;

--12. Give department wise maximum & minimum salary with department name. 
SELECT D.DepartmentName,
       MAX(P.Salary) AS MaximumSalary,
       MIN(P.Salary) AS MinimumSalary
FROM DEPARTMENT D
JOIN PERSON P
ON D.DEPARTMENTID = P.DEPARTMENTID
GROUP BY D.DepartmentName;

--13. Find city wise total, average, maximum and minimum salary.
SELECT City,
       SUM(Salary) AS TotalSalary,
       AVG(Salary) AS AverageSalary,
       MAX(Salary) AS MaximumSalary,
       MIN(Salary) AS MinimumSalary
FROM PERSON
GROUP BY City;

--14. Find the average salary of a person who belongs to Ahmedabad city. 
SELECT AVG(Salary) AS AverageSalary
FROM PERSON
WHERE City = 'Ahmedabad';

--15. Produce Output Like: <PersonName> lives in <City> and works in <DepartmentName> Department. (In 
--single column) 
SELECT P.PersonName || ' lives in ' || P.City ||
       ' and works in ' || D.DepartmentName ||
       ' Department.' AS PersonDetails
FROM PERSON P
JOIN DEPARTMENT D
ON P.DEPARTMENTID = D.DEPARTMENTID;

