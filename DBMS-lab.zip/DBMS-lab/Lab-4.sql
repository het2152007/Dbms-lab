--lab 4 

--part-a
select * from Student;


--1. Update SPI of all students from 7.00 to 8.00.
update Student
set spi = 8.00
where spi = 7.00;


--2. Change city of HETVI from RAJKOT to AHMEDABAD. 
update Student
set city ='ahmedabad'
where sname ='hetvi';

--3. Update SPI of DEEP to 9.20 and city to VADODARA. 
update student
set spi = 9.20,city = 'vadodara'
where sname = 'deep';

--4. Update SPI of DHARMIK to 8.50. 
update student
set spi = 8.50
where sname = 'dharmik';

--5. Update branch name from COMPUTER to IT.
update Student
set branch = 'it'
where branch = 'computer';

--6. Update branch of RAJ to AUTOMOBILE. 
update Student
set branch = 'automobile'
where sname = 'raj'

--7. Update SPI to 7.50 where STDID is between 103 and 107. 
update student
set spi = 7.50
where stdid between 103 and 107

--8. Update city of PARAG to MUMBAI. 
update student
set city = 'mumbai'
where sname = 'parag';

--9. Update SPI of RIYA to 6.00. 
update Student
set spi = 6.00
where sname = 'riya';

--10. Update SPI of SMAIR to 7.20 and branch to ELECTRICAL.
update Student
set spi = 7.20,branch = 'electrical'
where sname ='smair';

--part-b

--11. Give 10% increment in SPI.  
update student
set spi = spi*1.10;

--12. Increase SPI by 20% for all students.
update student
set spi = spi*1.20


--13. Increase SPI by 0.50 in all records. 
update Student
set spi = spi+0.50


--14. Update branch to 'EC' and SPI to 8.00 and city to Surat where SNAME is KRUNAL. 
update student
set branch = 'EC',spi = 8,city = 'surat'
where sname = 'krunal';

--15. Update city to 'RAJKOT' and SPI to 7.00 where branch is CIVIL and stdid is less than 105.
update student
set city = 'rajkot',spi = 7
where branch = 'civil' and stdid<105;

--part-c

--16. Update SPI of student with stdid 110 to NULL. 
update student
set spi = null
where stdid = 110;

--17. Update branch of VISHAL to NULL
update student
set branch = null
where sname = 'vishal';

--18. Display names of students whose SPI is NULL. 
select sname from student
where spi is null;

--19. Display students who have branch assigned. 
select sname from student
where branch is not null;

--20. Update student with stdid 108 to name DARSHAN, branch COMPUTER, and SPI 8.50.  
update student
set sname = 'darshan',branch = 'computer',spi = 8.50
where stdid = 108;

--21. Update city to SURAT where SPI is less than 7.00.  
update student
set city = 'surat'
where spi<7.00

--22. Update city to NULL and branch to MECHANICAL where stdid is 109. 
update student
set city = null,branch = 'mechanical'
where stdid = 109;


Create table emp(
eid int,
fname varchar(50),
lname varchar(50),
dept varchar(20),
salary decimal(8,2),
city varchar(20),
gender varchar(10),
joiningyear int
);

Insert into emp values 
(101,'HETVI','PATEL','ADMIN',12000,'RAJKOT','FEMALE',2026),
(102,'RAJ','MEHTA','IT',14000,'AHMEDABAD','MALE',2011),
(103,'VISHAL','SHARMA','HR',15000,'BARODA','MALE',2020),
(104,'DEEP','PATEL','ADMIN',12500,'RAJKOT','MALE',2026),
(105 ,'DHAVAL','SHAH','IT',15000,'JAMNAGAR','MALE',2024),
(106,'RIYA','KAUR','IT',5000,'AHMEDABAD','FEMALE',2024),
(107,'PARAG','PANDYA','HR',7000,'RAJKOT','MALE',2025),
(108,'VRUNDA','VYAS','SERVER',10000,'BARODA','FEMALE',2022),
(109,'MEHUL','SINGH','HR',12000,'MORBI','MALE',2020),
(110,'MUBIN','PARMAR','TRANSPORT',12000,'SURAT','MALE',2021),
(111,'MAYANK','PUROHIT','ACCOUNT',13000,NULL,'MALE',2020);

select * from emp;

