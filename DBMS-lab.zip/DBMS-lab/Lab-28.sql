--Lab 28

--Part – A: 
--1. Create trigger for printing message after employee record insertion. 
CREATE  TRIGGER emp_insert
ON EMPLOYEE
AFTER INSERT
AS
BEGIN
    
        PRINT'Employee record inserted successfully';
  
END;


--2. Create trigger for printing message after employee record update. 
CREATE TRIGGER emp_update
ON EMPLOYEE
AFTER UPDATE
AS
BEGIN
    PRINT 'Employee record updated successfully';
END;

--3. Create trigger for printing message after employee record deletion. 
CREATE TRIGGER emp_delete
ON EMPLOYEE
AFTER DELETE
AS
BEGIN
    PRINT 'Employee record deleted successfully';
END;

--4. Create trigger for printing message after employee salary increment. 
CREATE TRIGGER salary_increment
ON EMPLOYEE
AFTER UPDATE
AS
BEGIN
    IF UPDATE(SALARY)
    BEGIN
        PRINT 'Employee salary incremented successfully';
    END;
END;

--5. Create trigger for automatically converting CITY names into uppercase during insertion.
CREATE TRIGGER city_uppercase
ON EMPLOYEE
INSTEAD OF INSERT
AS
BEGIN
    INSERT INTO EMPLOYEE (EID, FIRSTNAME, SALARY, CITY)
    SELECT EID, FIRSTNAME, SALARY, UPPER(CITY)
    FROM INSERTED;
END;


--Part – B:

--6. Create trigger for updating employee city and printing old city and new city name.
CREATE TRIGGER emp_city_update
ON EMPLOYEE
AFTER UPDATE
AS
BEGIN
    IF UPDATE(CITY)
    BEGIN
        SELECT
            'Old City: ' + D.CITY +
            ', New City: ' + I.CITY AS Message
        FROM DELETED D
        INNER JOIN INSERTED I
        ON D.EID = I.EID;
    END;
END;

--7. Create trigger for automatically setting CITY as 'RAJKOT' if no city value is entered during employee insertion. 
CREATE TRIGGER emp_city_default
ON EMPLOYEE
INSTEAD OF INSERT
AS
BEGIN
    INSERT INTO EMPLOYEE
        (EID, FIRSTNAME, SALARY, CITY)
    SELECT
        EID,
        FIRSTNAME,
        SALARY,
        ISNULL(CITY, 'RAJKOT')
    FROM INSERTED;
END;

--8. Create trigger for automatically adding current year in JOININGYEAR if no value is entered. 
CREATE TRIGGER emp_joiningyear_default
ON EMPLOYEE
INSTEAD OF INSERT
AS
BEGIN
    INSERT INTO EMPLOYEE
        (EID, FIRSTNAME, SALARY, CITY, JOININGYEAR)
    SELECT
        EID,
        FIRSTNAME,
        SALARY,
        CITY,
        ISNULL(JOININGYEAR, YEAR(GETDATE()))
    FROM INSERTED;
END;

--9. Create trigger for printing employee full name after new employee insertion. 
CREATE TRIGGER emp_fullname
ON EMPLOYEE
AFTER INSERT
AS
BEGIN
    SELECT
        'Employee Full Name: ' +
        FIRSTNAME + ' ' + LASTNAME AS Message
    FROM INSERTED;
END;

--10. Create trigger for automatically assigning department as ‘GENERAL’ if DEPARTMENT value is NULL. 
CREATE TRIGGER emp_city_abcd
ON EMPLOYEE
AFTER INSERT
AS
BEGIN
    UPDATE EMPLOYEE
    SET CITY = 'RAJKOT'
    WHERE CITY IS NULL
      AND EID IN (
          SELECT EID FROM INSERTED
      );
END;
