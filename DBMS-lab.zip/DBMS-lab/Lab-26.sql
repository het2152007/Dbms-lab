--Lab 26 

--Part – A: 

--1. Create a table valued function to display all student records. 
CREATE FUNCTION dbo.GetAllStudents()
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM STUDENT
);
SELECT * FROM dbo.GetAllStudents();

--2. Create a table valued function that accepts CITY and returns all students from that city. 
CREATE FUNCTION dbo.GetStudentsByCity
(
    @CITY VARCHAR(50)
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM STUDENT
    WHERE CITY = @CITY
);
SELECT * FROM dbo.GetStudentsByCity('RAJKOT');

--3. Create a table valued function that accepts BRANCH and returns all students of that branch. 
CREATE FUNCTION dbo.GetStudentsByBranch
(
    @BRANCH VARCHAR(50)
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM STUDENT
    WHERE BRANCH = @BRANCH
);
SELECT * FROM dbo.GetStudentsByBranch('CE');

--4. Create a table valued function that accepts SPI and returns students whose SPI is greater than entered SPI. 
CREATE FUNCTION dbo.GetStudentsBySPI
(
    @SPI DECIMAL(4,2)
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM STUDENT
    WHERE SPI > @SPI
);
SELECT * FROM dbo.GetStudentsBySPI(8.00);

--5. Create a table valued function that accepts MIN_SPI and MAX_SPI and returns students whose SPI lies between given range. 
CREATE FUNCTION dbo.GetStudentsBySPIRange
(
    @MIN_SPI DECIMAL(4,2),
    @MAX_SPI DECIMAL(4,2)
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM STUDENT
    WHERE SPI BETWEEN @MIN_SPI AND @MAX_SPI
);
SELECT * FROM dbo.GetStudentsBySPIRange(7.00, 9.00);