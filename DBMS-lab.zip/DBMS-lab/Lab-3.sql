--lab 3 part-a
--1. Retrieve all data from table STUDENT. 
select * from Student;

--2. Display Student Name and City from STUDENT. 
select sname,city from student;

--3. Display student details of all students who belongs to COMPUTER branch.
select * from student
Where branch = 'computer';

--4. Display names of students whose ID is less than 105 from STUDENT table.
select * from student 
where stdid<105;

--5. Give Student Name, City and SPI of student whose SPI is greater than 6.50. 
select sname,city,spi from student
where spi>6.50;

--6. Give name of Student whose branch is COMPUTER and SPI is greater than 8.00. 
select sname from student
where branch='computer' and spi>8;

--7. Give names of students whose ID is greater than 103 and belongs to Rajkot city.  
select sname from student
where stdid>103 and city='rajkot';

--8. Display names of students who belong to either ‘RAJKOT’ or ‘SURAT’ city (USE OR & IN). 
select sname from student 
where city='rajkot' or city='surat';

--9. Display names of students with branch whose SPI is greater than 8.0 and ID is less than 105. 
select sname,branch from student 
where stdid<105 and spi>8; 

--10. Find all students whose SPI is greater than or equal to 7.0 and less than or equal to 9.0 (USE AND & BETWEEN). 
select sname from student 
where spi Between 7 and 9;

--11. Find all students who do not belong to ‘COMPUTER’ branch. 
select * from student
where branch!='computer';

--12. Display Student ID, Name & SPI of students who belong to ‘COMPUTER’, ‘CIVIL’ or ‘CHEMICAL’ branch and ID is less than 104. 
select stdid,sname,spi from student 
where stdid<104 and (branch='computer' or branch='chemical' or branch='civil'); 

--13. Display all student IDs and names who do not belong to ‘COMPUTER’ or ‘CIVIL’ branch (USE NOT IN).
select stdid,sname from student
where branch not in ('computer','civil');

--14. Display all student names other than ‘DEEP’ from STUDENT table (USE NOT, <>, !=). 
select sname from student
where sname!='deep';

--15. Display student names whose branch is not available (NULL) in STUDENT table.
select sname from student 
where branch is null;

--16. Retrieve all unique branches name from STUDENT table.
select distinct branch from student;

--17. Retrieve first 50% records from STUDENT table.
select top 50 percent * from student;

--18. Retrieve first five student IDs from STUDENT table. 
select top 5 stdid from student;

--lab3 part-b

--19. Display all the details of first five students from STUDENT table.
select top 5 * from student;

--20. Display all the details of first three students whose SPI is greater than 8.0.
select top 3 * from student
where spi>8;

--21. Display Student ID, Name of first five students whose branch does not belong to ‘COMPUTER’ branch.
select top 5 stdid,sname from student
where branch!='computer';

--22. Select all details with student IDs not in the range 105 to 109.
select * from student 
where stdid not Between 105 and 109;

--23. Select all records from STUDENT where SPI is greater than 7.0 and less than or equal to 9.0, and student ID is between 102 and 108. 
select * from student
where (spi BETWEEN 7.01 and 9.00) and (stdid Between 102 and 108);

--lab3 part-c

--24. Display all details of students who have SPI more than 8.5 without using * from STUDENT table. 
select stdid,sname,city,spi,branch from student;

--25. Retrieve names of students whose city is ‘RAJKOT’ and SPI is less than 8.00. 
select * from student 
where city='rajkot' and spi<8.00;

--26. Retrieve records from STUDENT table where SPI is greater than 8.0 and student ID is less than 105. 
select * from student 
where spi>8.00 and  stdid<105;

--27. Retrieve records from STUDENT table where SPI is greater than 7.5 and student ID is between 100 and 110 and city is ‘RAJKOT’ or ‘SURAT’. 
select * from student 
where spi>7.5 and (stdid between 100 and 110) and (city='rajkot' or city='surat');

--28. Display details of students who belong to ‘CIVIL’ or ‘MECHANICAL’ branch and SPI is greater than 8.0.
select * from student 
where (branch='civil' or branch='mechanical') and (spi>8);
