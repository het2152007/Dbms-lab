--Lab 13 Implement SQL Joins to Combine Multiple Tables From the table STUDENT_INFO and RESULT perform the following queries:  

--Part – A:

--1. Combine information from Student and Result table using cross join (Cartesian product). 
select * from student cross join RESULT

select * from student
select * from result

--2. Perform inner join on Student and Result tables. 
SELECT *
FROM Student
INNER JOIN Result
ON Student.stdid = Result.RNO;

--3. Perform the left outer join on Student and Result tables.
SELECT *
FROM Student
LEFT OUTER JOIN Result
ON Student.stdid = Result.rno;

--4. Perform the right outer join on Student and Result tables.
SELECT *
FROM Student
RIGHT OUTER JOIN Result
ON Student.stdid = Result.RNO;

--5. Perform the full outer join on Student and Result tables. 
SELECT *
FROM Student
FULL OUTER JOIN Result
ON Student.stdid = Result.RNO;

--6. Display Rno, Name, Branch and SPI of all students. 
SELECT S.stdid, S.sName, S.Branch, R.SPI
FROM Student S
INNER JOIN Result R
ON S.stdid = R.Rno;

--7. Display Rno, Name, Branch and SPI of CE branch students only.
select s.stdid, s.sname, s.branch, r.spi from
Student s inner join RESULT r 
on s.stdid = r.RNO
where s.branch = 'computer'

--8. Display Rno, Name, Branch and SPI of students other than EC branch.
select s.stdid, s.sname, s.branch, r.spi from
Student s inner join RESULT r 
on s.stdid = r.RNO
where s.branch != 'electrical'

--9. Display Rno, Name and SPI of students whose SPI is greater than 8.
select s.stdid, s.sname, s.branch from
Student s inner join RESULT r 
on s.stdid = r.RNO
where r.spi > 8

--10. Display Rno, Name and Branch of students whose SPI is less than 8.
select s.stdid, s.sname, s.branch from
Student s inner join RESULT r 
on s.stdid = r.RNO
where r.spi < 8

--11. Display average result of each branch
select branch,avg(r.SPI) from
Student s inner join RESULT r 
on s.stdid = r.RNO
group by s.branch

--12. Display average result of CE and ME branch.
select branch,avg(r.SPI) from
Student s inner join RESULT r 
on s.stdid = r.RNO
where branch = 'computer' or branch = 'machanical'
group by s.branch

--13. Display maximum and minimum SPI of each branch.
select branch,min(r.SPI) from
Student s inner join RESULT r 
on s.stdid = r.RNO
where branch = 'computer' or branch = 'machanical'
group by s.branch

--14. Display branch-wise student count in descending order.
select branch,COUNT(*) from
Student s inner join RESULT r 
on s.stdid = r.RNO
group by branch 
order by COUNT(*) desc;

--15. Display branch-wise total SPI of students. 
select branch,sum(r.SPI) from
Student s inner join RESULT r 
on s.stdid = r.RNO
group by branch 
