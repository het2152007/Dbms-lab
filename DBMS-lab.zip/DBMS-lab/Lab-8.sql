--Lab 8 Perform SQL Queries Using Aggregate Functions with GROUP BY Clause (Without HAVING) 
--From the tables EMPLOYEE perform the following queries 

--Part – A: 
select * from emp;

--1. Display the Highest, Lowest Salary and Label the columns Maximum, Minimum respectively.
select max(salary) as Highest_Salary,min(salary) as Lowest_Salary from emp

--2. Display Total, and Average salary of all employees. Label the columns Total_Sal and Average_Sal,respectively. 
select sum(salary) as total_Salary,cast(avg(salary) as decimal(10,2)) as average_Salary  from emp

--3. Find total number of employees of EMPLOYEE table.
select count(*) as total_employees from emp

--4. Find highest salary from Rajkot city. 
select city,max(salary) from emp
where city = 'rajkot'
group by city;

--5. Give maximum salary from IT departmen
select dept,max(salary) from emp
where dept = 'it'
group by dept;

--6. Count employee department is HR.
select dept,count(*) from emp
where dept = 'hr'
group by dept;

--7. Display average salary of Admin department.
select dept,avg(salary) as average_salary from emp
where dept ='admin'
group by dept


--8. Display total salary of HR department. 
select dept,sum(salary) as total_salary from emp
where dept = 'hr'
group by dept

--9. Count total number of cities of employee without duplication
select count(distinct city) as total_city from emp

--10. Count unique departments. 
select count(distinct dept) as total_dept from emp

--11. Display minimum salary of employee who belongs to Ahmedabad.
select city,min(salary) as minimum_salary from emp
where city = 'Ahmedabad'
group by city;

--12. Find city wise highest salary. 
select city,max(salary) as highest_salary from emp
group by city;

--13. Find department wise lowest salary. 
select dept,min(salary) as lowest_salary from emp
group by dept;

--14. Display minimum salary in each city. 
select city,min(salary) as lowest_salary from emp
group by city;

--15. Display average salary of employees from Surat. 
select city,avg(salary) as avg_salary from emp
where city ='surat'
group by city;

--16. Display total salary of female employees
select gender,sum(salary) as total_salary from emp
where gender ='female'
group by gender;

--17. Count number of male employees.
select gender,count(gender) as total_male from emp
where gender ='male'
group by gender;

--18. Display city with the total number of employees belonging to each city. 
select city,count(eid) as total_emp from emp
group by city;

--19. Count number of employees in each city where gender is MALE.
select city,count(*) as total_maleemp from emp
where gender ='male'
group by city;

--20. Display maximum salary in each department where city is not Ahmedabad. 
select dept,max(salary) as total_maleemp from emp
where city !='Ahmedabad'
group by dept;

--Part – B: 

--21. Display minimum salary in each city where gender is FEMALE.
select city,min(salary) as minimum_salary from emp
where gender = 'female'
group by city;

--22. Give total salary of each department of EMPLOYEE table. 
select dept,sum(salary) as total_salary from emp
group by dept;

--23. Give average salary of each department of EMPLOYEE table without displaying the respective department name. 
select avg(salary) as avg_salary from emp
group by dept;

--24. Count the number of employees for each department in every city. 
select dept,city,count(*) as total_number_fromeach_city from emp
group by dept , city;

--25. Calculate the total salary distributed to male and female employees.
select gender,sum(salary) as total_salary from emp
group by gender;

--Part – C: 

--26. Give city wise maximum and minimum salary of female employees.
select * from emp;
select city,min(salary) as min_salary,max(salary) as max_salary from emp
where gender = 'female'
group by city;

--27. Calculate department, city, and gender wise average salary. 
select dept,city,gender,avg(salary) from emp
group by dept,city,gender;

--28. Display the difference between the highest and lowest salaries. Label the column DIFFERENCE.
select max(salary) as highest,min(salary) as lowest, max(salary)-min(salary) as difference from emp;

--29. Display sum of salaries of department wise where department name consist 5 letter. 
select dept,sum(salary) as total_salary from emp
where dept like '_____'
group by dept;

--30. Find the Maximum salary department & city wise in which city name starts with ‘R’. 
select dept,city,max(salary) as max_salary from emp
where city like 'r%'
group by dept,city;
