--Lab 18 Perform SQL Queries Using Subqueries  
--From the table STUDENT perform the following queries:  

--Part – A:

--1. Display the details of students whose SPI is greater than the average SPI. 
SELECT *
FROM STUDENT
WHERE SPI > (SELECT AVG(SPI) FROM STUDENT);

--2. Display the names of students whose SPI is less than the average SPI. 
SELECT sNAME
FROM STUDENT
WHERE SPI < (SELECT AVG(SPI) FROM STUDENT);

--3. Display the student details who has the highest SPI. 
SELECT *
FROM STUDENT
WHERE SPI = (SELECT MAX(SPI) FROM STUDENT);

--4. Display the student details who has the lowest SPI. 
SELECT *
FROM STUDENT
WHERE SPI = (SELECT MIN(SPI) FROM STUDENT);


--5. Display the students whose SPI is greater than SPI of student DHARMIK. 
SELECT *
FROM STUDENT
WHERE SPI > (
    SELECT SPI
    FROM STUDENT
    WHERE sNAME = 'DHARMIK'
);

--6. Display the students whose SPI is less than SPI of student RIYA.
select * from student 
where spi < (select spi from student where sname = 'riya');

--7. Display the students who belong to the same branch as KRUNAL. 
select sname from student 
where branch = (select branch from student where sname='krunal') and sname != 'krunal'

--8. Display the students whose branch is different from HETVI. 
SELECT *
FROM STUDENT
WHERE BRANCH != (
    SELECT BRANCH
    FROM STUDENT
    WHERE sNAME = 'HETVI'
);

--9. Display the second highest SPI from RESULT table.  
SELECT MAX(SPI) AS SECOND_HIGHEST_SPI
FROM RESULT
WHERE SPI < (SELECT MAX(SPI) FROM RESULT);

--10. Display the second lowest SPI from RESULT table.   
SELECT MIN(SPI) AS SECOND_LOWEST_SPI
FROM RESULT
WHERE SPI > (SELECT MIN(SPI) FROM RESULT);


--11. Display the names of students whose SPI is above branch-wise average S
SELECT sNAME
FROM STUDENT S
WHERE SPI > (
    SELECT AVG(SPI)
    FROM STUDENT
    WHERE BRANCH = S.BRANCH
);


--12. Display the branch having maximum average SPI.  
SELECT BRANCH
FROM STUDENT
GROUP BY BRANCH
HAVING AVG(SPI) = (

    SELECT MAX(AVG_SPI)
    FROM (
        SELECT BRANCH, AVG(SPI) AS AVG_SPI
        FROM STUDENT
        GROUP BY BRANCH
    ) x
);
