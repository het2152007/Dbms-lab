--Lab 27 Implement Cursors for Row-by-Row Data Processing 
-- From the table EMPLOYEE perform the following queries:  

--Part – A: 

--1. Create a cursor Employee_Cursor to fetch all rows from EMPLOYEE table and display them.
DECLARE Employee_Cursor CURSOR FOR
SELECT *
FROM emp

OPEN Employee_Cursor;

FETCH NEXT FROM Employee_Cursor;

WHILE @@FETCH_STATUS = 0
BEGIN
    FETCH NEXT FROM Employee_Cursor;
END;

CLOSE Employee_Cursor;
DEALLOCATE Employee_Cursor;

--2. Create a cursor to display all female employees from EMPLOYEE table. 
DECLARE Female_Cursor CURSOR FOR
SELECT EID, FNAME, LNAME
FROM emp
WHERE GENDER = 'Female';

OPEN Female_Cursor;

DECLARE @EmployeeRow VARCHAR(200);

FETCH NEXT FROM Female_Cursor;

WHILE @@FETCH_STATUS = 0
BEGIN
    FETCH NEXT FROM Female_Cursor;
END;

CLOSE Female_Cursor;
DEALLOCATE Female_Cursor;


--3. Create a cursor Employee_Cursor_Fetch to fetch records in form of EID_FirstName_LastName. 
--(Example: 101_Hetvi_Patel) 
DECLARE Employee_Cursor_Fetch CURSOR LOCAL FAST_FORWARD FOR
SELECT EID, FNAME, LNAME
FROM EMP;

OPEN Employee_Cursor_Fetch;

DECLARE @Row VARCHAR(200);

FETCH NEXT FROM Employee_Cursor_Fetch;

WHILE @@FETCH_STATUS = 0
BEGIN
    FETCH NEXT FROM Employee_Cursor_Fetch;
END;

CLOSE Employee_Cursor_Fetch;
DEALLOCATE Employee_Cursor_Fetch;

--4. Create a cursor to find and display all employees with Salary greater than 12000. 
DECLARE Salary_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT EID, FNAME, LNAME, SALARY
FROM EMP
WHERE SALARY > 12000;

OPEN Salary_Cursor;

FETCH NEXT FROM Salary_Cursor;

WHILE @@FETCH_STATUS = 0
BEGIN
    FETCH NEXT FROM Salary_Cursor;
END;

CLOSE Salary_Cursor;
DEALLOCATE Salary_Cursor;


--5. Create a cursor to display all employees who joined in year 2022 or later. 
DECLARE Joining_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT EID, FNAME, LNAME, joiningyear
FROM EMP
WHERE joiningyear >= '2022';

OPEN Joining_Cursor;

FETCH NEXT FROM Joining_Cursor;

WHILE @@FETCH_STATUS = 0
BEGIN
    FETCH NEXT FROM Joining_Cursor;
END;

CLOSE Joining_Cursor;
DEALLOCATE Joining_Cursor;

SELECT EID, FNAME, LNAME, joiningyear
FROM EMP
WHERE joiningyear >= '2022';

--6. Create a cursor to fetch Employee Name with Department Name. 
--(Example: Raj Mehta works in IT Department) 
DECLARE @FNAME VARCHAR(50),
        @LNAME VARCHAR(50),
        @dept VARCHAR(50);

DECLARE Department_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT FNAME, LNAME, dept
FROM EMP;

OPEN Department_Cursor;

FETCH NEXT FROM Department_Cursor
INTO @FNAME, @LNAME, @dept;

WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @FNAME + ' ' + @LNAME
          + ' works in ' + @dept + ' Department';

    FETCH NEXT FROM Department_Cursor
    INTO @FNAME, @LNAME, @dept;
END;

CLOSE Department_Cursor;
DEALLOCATE Department_Cursor;

SELECT * FROM EMP
SELECT * FROM DEPARTMENT


--7. Create a cursor to update CITY as ‘AHMEDABAD’ for employees whose CITY value is NULL. 
DECLARE @EID INT;

DECLARE City_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT EID
FROM EMP
WHERE CITY IS NULL;

OPEN City_Cursor;

FETCH NEXT FROM City_Cursor INTO @EID;

WHILE @@FETCH_STATUS = 0
BEGIN
    UPDATE EMP
    SET CITY = 'AHMEDABAD'
    WHERE EID = @EID;

    PRINT 'City updated for Employee ID: '
          + CAST(@EID AS VARCHAR(10));

    FETCH NEXT FROM City_Cursor INTO @EID;
END;

CLOSE City_Cursor;
DEALLOCATE City_Cursor;

--8. Create a cursor to display Employee Name with City Name. 
--(Example: Deep Patel lives in Rajkot) 
DECLARE @FNAME VARCHAR(50),
        @LNAME VARCHAR(50),
        @CITY VARCHAR(50);

DECLARE Employee_City_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT FNAME, LNAME, CITY
FROM EMP;

OPEN Employee_City_Cursor;

FETCH NEXT FROM Employee_City_Cursor
INTO @FNAME, @LNAME, @CITY;

WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT ISNULL(@FNAME, '') + ' '
        + ISNULL(@LNAME, '') + ' lives in '
        + ISNULL(@CITY, 'Unknown');

    FETCH NEXT FROM Employee_City_Cursor
    INTO @FNAME, @LNAME, @CITY;
END;

CLOSE Employee_City_Cursor;
DEALLOCATE Employee_City_Cursor;


--9. Create a cursor to delete employees whose Salary is less than 5000. 
DECLARE @EID INT;

DECLARE Delete_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT EID
FROM EMP
WHERE Salary < 5000;

OPEN Delete_Cursor;

FETCH NEXT FROM Delete_Cursor INTO @EID;

WHILE @@FETCH_STATUS = 0
BEGIN
    DELETE FROM EMP
    WHERE EID = @EID;

    PRINT 'Deleted Employee ID: '
          + CAST(@EID AS VARCHAR(10));

    FETCH NEXT FROM Delete_Cursor INTO @EID;
END;

CLOSE Delete_Cursor;
DEALLOCATE Delete_Cursor;

--10. Create a cursor to display employees department-wise. 

DECLARE @FNAME VARCHAR(50),
        @LNAME VARCHAR(50),
        @dept VARCHAR(50);

DECLARE Department_Wise_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT FNAME, LNAME, dept
FROM EMP
ORDER BY dept;       

OPEN Department_Wise_Cursor;

FETCH NEXT FROM Department_Wise_Cursor
INTO @FNAME, @LNAME, @dept;

WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT ISNULL(@dept, 'Unknown Department')
          + ' Department: '
          + ISNULL(@FNAME, '') + ' '
          + ISNULL(@LNAME, '');

    FETCH NEXT FROM Department_Wise_Cursor
    INTO @FNAME, @LNAME, @dept;
END;

CLOSE Department_Wise_Cursor;
DEALLOCATE Department_Wise_Cursor;
