--Lab 16 Implement Advanced SQL Joins (Level-2) 
--From the table STADIUM, TEAM and PLAYER perform the following queries:  

--Part – A: 
SELECT * FROM PLAYER
SELECT * FROM TEAM
SELECT * FROM STADIUM
--1. Display players who belong to teams located in ‘Mumbai’. 
SELECT P.*
FROM PLAYER P
JOIN TEAM T ON P.Team_ID = T.Team_ID
JOIN STADIUM S ON T.HOME_STADIUM_ID = S.Stadium_ID
WHERE S.STADIUM_CITY = 'Mumbai';

--2. Display all teams and players. 
SELECT T.Team_Name, P.*
FROM TEAM T
LEFT JOIN PLAYER P
ON T.Team_ID = P.Team_ID;

--3. Display players along with team wins and stadium city. 
SELECT P.PLAYER_FIRST_NAME, T.TEAM_WINS, S.STADIUM_CITY
FROM PLAYER P
JOIN TEAM T ON P.Team_ID = T.Team_ID
JOIN STADIUM S ON T.HOME_STADIUM_ID = S.Stadium_ID;

--4. Display team name and number of players in each team. 
SELECT T.Team_Name, COUNT(P.Player_ID) AS Total_Players
FROM TEAM T
LEFT JOIN PLAYER P
ON T.Team_ID = P.Team_ID
GROUP BY T.Team_ID, T.Team_Name;

--5. Display team name, coach, and number of bowlers in each team. 
SELECT T.Team_Name, T.TEAM_COACH,
       COUNT(CASE WHEN P.PLAYER_ROLE = 'Bowler' THEN 1 END)
       AS Total_Bowlers
FROM TEAM T
LEFT JOIN PLAYER P
ON T.Team_ID = P.Team_ID
GROUP BY T.Team_ID, T.Team_Name, T.TEAM_COACH;

--6. Display team name with count of batsmen, bowlers, and all-rounders. 
SELECT T.Team_Name,
       COUNT(CASE WHEN P.PLAYER_ROLE = 'Batsman' THEN 1 END)
       AS Batsmen,
       COUNT(CASE WHEN P.PLAYER_ROLE = 'Bowler' THEN 1 END)
       AS Bowlers,
       COUNT(CASE WHEN P.PLAYER_ROLE = 'All-Rounder' THEN 1 END)
       AS All_Rounders
FROM TEAM T
LEFT JOIN PLAYER P
ON T.Team_ID = P.Team_ID
GROUP BY T.Team_ID, T.Team_Name;

--7. Display stadiums where teams have won more than 10 matches. 
SELECT DISTINCT S.*
FROM STADIUM S
JOIN TEAM T
ON S.Stadium_ID = T.HOME_STADIUM_ID
WHERE T.TEAM_WINS > 10;

--8. Display team name and number of players whose matches played is greater than 25. 
SELECT T.Team_Name,
       COUNT(P.Player_ID) AS Total_Players
FROM TEAM T
JOIN PLAYER P
ON T.Team_ID = P.Team_ID
WHERE P.PLAYER_MATCHES_PLAYED > 25
GROUP BY T.Team_ID, T.Team_Name;

--9. Display team name and total number of players having jersey number greater than 30. 
SELECT T.Team_Name,
       COUNT(P.Player_ID) AS Total_Players
FROM TEAM T
JOIN PLAYER P
ON T.Team_ID = P.Team_ID
WHERE P.PLAYER_JERSEY_NUMBER > 30
GROUP BY T.Team_ID, T.Team_Name;

--10. Display team name and total matches played by its players. 
SELECT T.Team_Name,
       COALESCE(SUM(P.PLAYER_MATCHES_PLAYED), 0)
       AS Total_Matches_Played
FROM TEAM T
LEFT JOIN PLAYER P
ON T.Team_ID = P.Team_ID
GROUP BY T.Team_ID, T.Team_Name;
