Create database cse_3a_19

use cse_3a_19


--lab2
Create table Deposit(
actno int,
cname varchar(50),
bname varchar(50),
amount decimal(8,2),
adate datetime)

Insert into Deposit Values
(101,'meet','mavdi',10000,'1-3-2025'),
(102,'jay','madhapar',5000,'4-1-2026'),
(103,'rahul','bedi',3500,'7-1-2026'),
(104,'riya','mavdi',1200,'7-6-2025'),
(105,'mansi','k.k.v hall',3000,'2-3-2024'),
(106,'diya','madhapar',2000,'1-3-2025'),
(107,'miral','bedi',9000,'5-9-2025'),
(108,'uday','umiya chowk',5000,'2-7-2025'),
(109,'charmi','shital park',8000,'2-8-2026'),
(110,'bansi','ring road',8000,'2-2-2025'),
(111,'bansi',null,9000,'1-1-2025');

Select * from Deposit

Create table Student(
stdid int,
sname varchar(50),
city varchar(50),
spi decimal(4,2),
branch varchar(50)
);

insert into Student values
(101,'hetvi','rajkot',7.40,'computer'),
(102,'raj','morbi',9.50,'machanical'),
(103,'vishal','rajkot',9,'civil'),
(104,'deep','surat',8.80,'computer'),
(105,'dharmik','baroda',8.80,'chemical'),
(106,'krunal','vapi',9.50,'civil'),
(107,'riya','navsari',5.50,'computer'),
(108,'vrunda','kutch',7.60,'electrical'),
(109,'smair','jamnugar',6.80,'ec'),
(110,'parag','surat',7,'chemical'),
(111,'harsh','rajkot',4,null);



  

























