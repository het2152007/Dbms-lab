--Lab 21 Implement Intermediate Common Table Expressions (CTE) for Query Simplification 
-- From the table STUDENT perform the following queries:  

--Part – A:

--1. Display all students whose SPI is greater than 8. 
WITH CTE_STUDENT AS (
    SELECT *
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI > 8;

--2. Display average SPI of all students. 
with cte_avg as(
    select avg(spi) as avg
    from Student
    )
select * from cte_avg

--3. Display total number of students in each branch. 
with total_each as(
    select branch,COUNT(*) as total_stu
    from student
    group by branch
    )
    select * from total_each


--4. Display students who belong to RAJKOT city. 
with city_rajkot as(
    select sname 
    from Student
    where city = 'rajkot'
    )
    select * from city_rajkot


--5. Find branch names that appear more than once. 
WITH morethen_once as(
    select branch,count(*) as total
    from student
    group by branch
    having count(*) > 1
    )
    select * from morethen_once

--6. Display row number for each student. 
WITH CTE_STUDENT AS (
    SELECT *,
           ROW_NUMBER() OVER (ORDER BY STDID) AS ROW_NUM
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT;


--7. Display top 3 students based on SPI. 
WITH CTE_STUDENT AS (
    SELECT *,
           ROW_NUMBER() OVER (ORDER BY SPI DESC) AS RN
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE RN <= 3;

--8. Display students having maximum SPI. 
WITH CTE_STUDENT AS (
    SELECT *,
           MAX(SPI) OVER () AS MAX_SPI
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI = MAX_SPI;

--9. Display students having minimum SPI. 
WITH CTE_STUDENT AS (
    SELECT *,
           MIN(SPI) OVER () AS MIN_SPI
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI = MIN_SPI;

--10. Display branch -wise rank of students. 
WITH CTE_STUDENT AS (
    SELECT *,
           RANK() OVER (
               PARTITION BY BRANCH
               ORDER BY SPI DESC
           ) AS BRANCH_RANK
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
ORDER BY BRANCH, BRANCH_RANK;


--Part – B: 
--11. Display students SPI average belonging to Computer branch. 
WITH CTE_STUDENT AS (
    SELECT SPI
    FROM STUDENT
    WHERE BRANCH = 'COMPUTER'
)
SELECT AVG(SPI) AS AVG_SPI
FROM CTE_STUDENT;

--12. Display students whose SPI is greater than average SPI of his/her branch. 
WITH CTE_STUDENT AS (
    SELECT stdid, SNAME, BRANCH, CITY, SPI,
           AVG(SPI) OVER (PARTITION BY BRANCH) AS AVG_SPI
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI > AVG_SPI;

--13. Display branch having more than 2 students. 
WITH CTE_BRANCH AS (
    SELECT BRANCH, COUNT(*) AS TOTAL_STUDENTS
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, TOTAL_STUDENTS
FROM CTE_BRANCH
WHERE TOTAL_STUDENTS > 2;

--14. Display branches having average SPI between 7 and 9
WITH CTE_BRANCH AS (
    SELECT BRANCH, AVG(SPI) AS AVG_SPI
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, AVG_SPI
FROM CTE_BRANCH
WHERE AVG_SPI BETWEEN 7 AND 9;

--15. Display students whose SPI is lower than overall average SPI. 
WITH CTE_STUDENT AS (
    SELECT STDID, SNAME, BRANCH, CITY, SPI,
           AVG(SPI) OVER () AS AVG_SPI
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI < AVG_SPI;
 

--Part – C: 
--16. Display branches having exactly one student.
WITH CTE_BRANCH AS (
    SELECT BRANCH, COUNT(*) AS TOTAL_STUDENTS
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, TOTAL_STUDENTS
FROM CTE_BRANCH
WHERE TOTAL_STUDENTS = 1;

--17. Display branch having highest average SPI. 
WITH CTE_BRANCH AS (
    SELECT BRANCH, AVG(SPI) AS AVG_SPI
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, AVG_SPI
FROM CTE_BRANCH
WHERE AVG_SPI = (
    SELECT MAX(AVG_SPI)
    FROM CTE_BRANCH
);

--18. Display branch having lowest average SPI. 
WITH CTE_BRANCH AS (
    SELECT BRANCH, AVG(SPI) AS AVG_SPI
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, AVG_SPI
FROM CTE_BRANCH
WHERE AVG_SPI = (
    SELECT MIN(AVG_SPI)
    FROM CTE_BRANCH
);

--19. Display students whose SPI is lower than branch average SPI. 
WITH CTE_STUDENT AS (
    SELECT STDID, SNAME, BRANCH, CITY, SPI,
           AVG(SPI) OVER (
               PARTITION BY BRANCH
           ) AS AVG_SPI
    FROM STUDENT
)
SELECT *
FROM CTE_STUDENT
WHERE SPI < AVG_SPI;

--20. Display branches having maximum number of students.
WITH CTE_BRANCH AS (
    SELECT BRANCH, COUNT(*) AS TOTAL_STUDENTS
    FROM STUDENT
    GROUP BY BRANCH
)
SELECT BRANCH, TOTAL_STUDENTS
FROM CTE_BRANCH
WHERE TOTAL_STUDENTS = (
    SELECT MAX(TOTAL_STUDENTS)
    FROM CTE_BRANCH
);


--Lab 25 Implement User Defined Functions (UDF) in SQL (Scalar Function) 

-- Part – A:  

--1. Implement scalar function to return "Welcome to DBMS Lab". 
CREATE FUNCTION WelcomeMessage()
RETURNS VARCHAR(50)
AS
BEGIN
    RETURN 'Welcome to DBMS Lab';
END;
GO

SELECT dbo.WelcomeMessage() AS Message;

--2. Implement scalar function to calculate simple interest. 
CREATE FUNCTION SimpleInterest
(
    @P FLOAT,
    @R FLOAT,
    @T FLOAT
)
RETURNS FLOAT
AS
BEGIN
    RETURN (@P * @R * @T) / 100;
END;
GO

SELECT dbo.SimpleInterest(10000, 5, 2) AS Simple_Interest;

--3. Implement scalar function to find difference in days between two dates. 
CREATE FUNCTION DateDifference
(
    @Date1 DATE,
    @Date2 DATE
)
RETURNS INT
AS
BEGIN
    RETURN ABS(DATEDIFF(DAY, @Date1, @Date2));
END;
GO

SELECT dbo.DateDifference('2026-01-01', '2026-01-10') AS Difference_In_Days;

--4. Implement scalar function to check whether number is odd or even. 
CREATE FUNCTION OddEven
(
    @N INT
)
RETURNS VARCHAR(10)
AS
BEGIN
    IF @N % 2 = 0
        RETURN 'Even';
    RETURN 'Odd';
END;
GO

SELECT dbo.OddEven(7) AS Result;
SELECT dbo.OddEven(10) AS Result;

--5. Implement scalar function to print numbers from 1 to N. 
CREATE FUNCTION PrintNumbers
(
    @N INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
    DECLARE @I INT = 1;
    DECLARE @Result VARCHAR(MAX) = '';

    WHILE @I <= @N
    BEGIN
        SET @Result = @Result + CAST(@I AS VARCHAR(10));

        IF @I < @N
            SET @Result = @Result + ', ';

        SET @I = @I + 1;
    END;

    RETURN @Result;
END;
GO

SELECT dbo.PrintNumbers(10) AS Numbers;
