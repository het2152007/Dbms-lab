--Lab 10 Implement SQL In-Built Functions for Mathematical and String Operations 
--Math functions 

--Part – A:

--1. Display the result of 5 multiply by 30.
select 5*30;

--2. Find out the absolute value of -25, 25, -50 and 50. 
select abs(-25),abs(25),(-50),(50);

--3. Find smallest integer value that is greater than or equal to 25.2, 25.7 and -25.2.
select ceiling(25.2),ceiling(25.7),ceiling(-25.2)

--4. Find largest integer value that is smaller than or equal to 25.2, 25.7 and -25.2. 
select floor(25.2),floor(25.7),floor(-25.2)

--5. Find out remainder of 5 divided 2 and 5 divided by 3. 
select 5%2,5%3

--6. Find out value of 3 raised to 2nd power and 4 raised 3rd power.
select power(3,2),power(4,3)

--7. Find out the square root of 25, 30 and 50. 
select sqrt(25),sqrt(30),sqrt(50)

--8. Find out the square of 5, 15, and 25.
select square(5),square(15),square(25)

--9. Find out the value of PI.
select pi();

--10. Find out round value of 157.732 for 2, 0 and -2 decimal points.
select round(157.732,2),round(157.732,0),round(157.732,-2)

--11. Find out exponential value of 2 and 3. 
select exp(2),exp(3)

--12. Find out logarithm having base e of 10 and 2. 
select log(10,2)

--13. Find logarithm base 10 of 5 and 100
select LOG10(5),LOG10(100)

--14. Find sine, cosine and tangent of 3.1415. 
select SIN(3.1415),COS(3.1415),cos(3.1415)

--15. Find sign of -25, 0 and 25. 
select sign(-25),sign(0),sign(25)

--16. Generate random number using function.
select rand()

--String functions 
--Part – A: 

--1. Find the length of following. (I) NULL    (II) ‘   hello     ’   (III)  Blank 
select len('hello'), len(null), len(' ')

--2. Display your name in lower & upper case. 
select lower('het'),upper('het')

--3. Display first three characters of your name. 
select LEFT ('het sanchaniya',3)

--4. Display 3rd to 10th character of your name. 
SELECT SUBSTRING('SANCHANIYA HET',3,10)

--5. Write a query to convert ‘abc123efg’ to ‘abcXYZefg’ & ‘abcabcabc’ to ‘ab5ab5ab5’ using REPLACE. 
SELECT REPLACE('abc123efg','123','XYZ')

--6. Write a query to display ASCII code for ‘a’,’A’,’z’,’Z’, 0, 9. 
select ascii('a'),ascii('A'),ascii('z'),ascii('Z'),ascii(0),ascii(9)

--7. Write a query to display character based on number 97, 65,122,90,48,57. 
select char(97),char(65),char(122),char(90),char(48),char(57)

--8. Write a query to remove spaces from left of a given string ‘ hello world  
select ltrim(' hello world')

--9. Write a query to remove spaces from right of a given string ‘ ‘. hello world 
select RTRIM('hello world   ')

--10. Write a query to display first 4 & Last 5 characters of ‘SQL Server’. 
select concat(left('SQL Server',4),right('SQL Server',5))

--11. Write a query to convert a string ‘1234.56’ to number (Use cast and convert function). 
select cast('1234.56' as decimal(6,2))

--12. Write a query to convert a float 10.58 to integer (Use cast and convert function). 
select cast(10.58 as int),convert(int, 10.58)

--13. Put 10 space before your name using function.
select space(10)+'het'

---14. Combine two strings using + sign as well as CONCAT ().
select 'darshan'+ ' ' + 'university',concat('darshan','university')

--15. Find reverse of “Darshan”. 
select REVERSE('darshan')

--16. Repeat your name 3 times
select REPLICATE('het ',3)


--Part – B: Perform following queries on EMPLOYEE table
select * from emp

--17. Display FIRSTNAME and LASTNAME in lowercase and uppercase. 
select lower(fname),lower(lname),upper(fname),upper(lname) from emp

--18. Display full name by combining FIRSTNAME and LASTNAME. 
select concat(fname,' ',lname) as fullname from emp

--19. Display FIRSTNAME with first 3 characters only.
select left(fname,3) from emp

--20. Display LASTNAME with last 2 characters only. 
select right(lname,2) from emp

--21. Display length of each employee’s FIRSTNAME.
select len(fname) from emp

--22. Display FIRSTNAME after replacing ‘A’ with ‘@’. 
select REPLACE(fname,'a','@') from emp

--23. Display FIRSTNAME and LASTNAME with - between them using CONCAT.
select concat(fname,'-',lname) from emp

--Part – C: Perform following queries on EMPLOYEE table. 

--24. Display FIRSTNAME without first and last character
select fname,SUBSTRING(fname,2,len(fname)-2) from emp;

--25. Display FIRSTNAME after replacing vowels with '*'.

--26. Display employees where combined length of FIRSTNAME and LASTNAME is greater than 10.
select fname,lname from emp
where (len(fname)+len(lname)) > 10

--27. Display FIRSTNAME and its reverse. 
select fname,REVERSE(fname) from emp

--28. Display employees whose FIRSTNAME and LASTNAME start with same character using LEFT()
select fname,lname from emp
where (left(fname,1) = left(lname,1));
