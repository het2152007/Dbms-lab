--Lab 15 Implement Advanced SQL Joins (Level-1) 
-- From the table PUBLISHER, AUTHOR and BOOK perform the following queries:  


--Part – A: 
select * from AUTHOR
select * from BOOK
--1. List all books with their authors. 
SELECT B.TITLE, A.AuthorName
FROM BOOK B
JOIN AUTHOR A
ON B.AuthorId = A.AuthorId;

--2. List all books with their publishers. 
SELECT B.TITLE , P.PublisherName
FROM BOOK B
JOIN PUBLISHER P
ON B.PublisherId = P.PublisherId;

--3. List all books with their authors and publishers. 
SELECT B.TITLE,
       A.AuthorName,
       P.PublisherName
FROM BOOK B
JOIN AUTHOR A
ON B.AuthorId = A.AuthorId
JOIN PUBLISHER P
ON B.PublisherId = P.PublisherId;

--4. List all books published after 2010 with their authors and publisher and price. 
SELECT B.TITLE,
       A.AuthorName,
       P.PublisherName,
       B.Price
FROM BOOK B
JOIN AUTHOR A
ON B.AuthorId = A.AuthorId
JOIN PUBLISHER P
ON B.PublisherId = P.PublisherId
WHERE B.PUBLICATIONYEAR > 2010;

--5. List all authors and the number of books they have written. 
SELECT A.AuthorName,
       COUNT(B.BookId) AS NumberOfBooks
FROM AUTHOR A
LEFT JOIN BOOK B
ON A.AuthorId = B.AuthorId
GROUP BY A.AuthorName;

--6. List all publishers and the total price of books they have published. 
SELECT P.PublisherName,
       SUM(B.Price) AS TotalPrice
FROM PUBLISHER P
LEFT JOIN BOOK B
ON P.PublisherId = B.PublisherId
GROUP BY P.PublisherName;

--7. List authors who have not written any books. 
SELECT A.AuthorName
FROM AUTHOR A
LEFT JOIN BOOK B
ON A.AuthorId = B.AuthorId
WHERE B.BookId IS NULL;

--8. Display the total number of books written by each author along with the average price of their books. 
SELECT A.AuthorName,
       COUNT(B.BookId) AS TotalBooks,
       AVG(B.Price) AS AveragePrice
FROM AUTHOR A
LEFT JOIN BOOK B
ON A.AuthorId = B.AuthorId
GROUP BY A.AuthorName;

--9. lists each publisher along with the total number of books they have published, sorted from highest to 
--lowest. 
SELECT P.PublisherName,
       COUNT(B.BookId) AS TotalBooks
FROM PUBLISHER P
LEFT JOIN BOOK B
ON P.PublisherId = B.PublisherId
GROUP BY P.PublisherName
ORDER BY TotalBooks DESC;

--10. Display number of books published each year. 
SELECT PUBLICATIONYEAR,
       COUNT(BookId) AS NumberOfBooks
FROM BOOK
GROUP BY PUBLICATIONYEAR
ORDER BY PUBLICATIONYEAR;

